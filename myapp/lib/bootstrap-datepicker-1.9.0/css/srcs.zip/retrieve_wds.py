import csv
import json
import os
import urllib.parse
import urllib.request

points = list(csv.DictReader(open('points.csv', encoding='euc-kr')))

os.makedirs('./output', exist_ok=True)

items = [
    'estimation:tmin',
    'estimation:tmax',
    'estimation:hm',
    'estimation:rain',
    'estimation:ins',
    'estimation:sunshine',
    'estimation:wsa',
    'estimation:wsx',
]

regions = [
    ('태백', 'taebaek'),
    ('무안', 'muan'),
    ('강릉', 'gangneung'),
    ('해남', 'haenam'),
    ('제주', 'jeju'),
    ('서귀포', 'jeju'),
]


def find_region_eng(location):
    for kor, eng in regions:
        if kor in location:
            return eng


def download(region_eng, items, begin, end, lon, lat):
    items_str = ','.join(items)
    url = f'http://{region_eng}.wds2019.agdcm.kr/farm/pickvalue/{items_str}/{begin}:{end}/{lon},{lat}/flatten'
    print(url)
    resp = urllib.request.urlopen(url).read().decode('utf-8')
    data = json.loads(resp)

    items_, dates, lonlats_ = data['header']
    values = data['values']

    header = 'date,' + items_str

    rows = [header]
    for i, value in enumerate(values):
        nv = [dates[i]] + [str(x) for x in value]
        rows.append(','.join(nv))

    return '\n'.join(rows)


def main():
    for point in points:
        crop = point['crop']
        location = point['location']
        lat = point['latitude']
        lon = point['longitude']

        region_eng = find_region_eng(location)
        data = download(region_eng, items, '20150101', '20181101', lon, lat)

        fn = f'{crop}.{location}({lon},{lat}).csv'
        print(fn)
        fp = open(f'./output/{fn}', 'w', encoding='euc-kr')
        fp.write(data)


if __name__ == '__main__':
    main()
